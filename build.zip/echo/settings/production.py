from .common import *

DEBUG = False

ALLOWED_HOSTS = ['0.0.0.0', 'localhost', '127.0.0.1', 'app.expert-echo.com', '164.90.188.64', '*']
"""
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'echo',
        'USER': 'doadmin',
        'PASSWORD': 'bo2x76411zj037fi',
        'HOST': 'db-postgresql-fra1-27152-do-user-7621625-0.a.db.ondigitalocean.com',
        'PORT': '25060',
    }
}"""

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'echoapp',
        'USER': 'django',
        'PASSWORD': 'Owbq4rT4_RqC',
        'HOST': POSTGRES_HOST,
        'PORT': '5432',
    }
}

CHANNEL_LAYERS = {
    "default": {
        "BACKEND": "channels_redis.core.RedisChannelLayer",
        "CONFIG": {
            "hosts": [("127.0.0.1", 6379)],
        },
    },
}

STATIC_ROOT = os.path.join(BASE_DIR, "public/static")

MEDIA_ROOT = os.path.abspath(os.path.join(BASE_DIR, "../", "data"))


print('Using production settings')