import json

import requests

from django.utils.log import AdminEmailHandler


class SlackHandler(AdminEmailHandler):
    def send_mail(self, subject, message, *args, **kwargs):
        data = {'text': message}
        requests.post("https://hooks.slack.com/services/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",
                      data=json.dumps(data), headers={'Content-Type': 'application/json'})
